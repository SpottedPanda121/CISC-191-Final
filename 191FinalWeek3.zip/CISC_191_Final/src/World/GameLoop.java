/**
 * Lead Author(s):
 * 
 * @author devin; student ID
 * @author Full name; student ID
 *         <<Add additional lead authors here>>
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *         References:
 *         Morelli, R., & Walde, R. (2016).
 *         Java, Java, Java: Object-Oriented Problem Solving
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 *         <<Add more references here>>
 *
 *         Version: 2025-04-12
 */
package World;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.*;

/**
 * Purpose: The reponsibility of GameLoop is ...
 *
 * GameLoop is-a ...
 * GameLoop is ...
 */
public class GameLoop extends JFrame
{

	public GameLoop()
	{
		boolean gameOver = false;
		JWindow game = new JWindow();
		// lets the window close upon pressing the X in the corner
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Sets the title of the window to "Gone Fishing"
		this.setTitle("Mountain Game");
		// Sets the window layout to be a BorderLayout
		this.setLayout(new GridLayout(16, 16));
		// Sets the size of the window to be 780p x 380p
		this.setMinimumSize(new Dimension(780, 380));

		JLabel test = new JLabel();
		this.add(test);

		// packs up the window
		this.pack();
		// sets the window to be visible
		this.setVisible(true);

	}

	public void paintComponent(Graphics a)
	{

	}
}
