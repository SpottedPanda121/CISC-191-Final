/**
 * Lead Author(s):
 * 
 * @author Fern; student ID
 * @author Full name; student ID
 *         <<Add additional lead authors here>>
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *         References:
 *         Morelli, R., & Walde, R. (2016).
 *         Java, Java, Java: Object-Oriented Problem Solving
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 *         <<Add more references here>>
 *
 *         Version: 2025-03-29
 */
package World;
import project.exam.*;

/**
 * Purpose: The reponsibility of Level is to create the level for the player to
 * traverse.
 *
 * Level is part of an Area
 * Level is part of a World
 * Level is ...
 */
public class Level extends Area
{
	

}
