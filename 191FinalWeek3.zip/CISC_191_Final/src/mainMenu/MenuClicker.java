/**
 * Lead Author(s):
 * 
 * 
 * @author Fern; student ID
 * @author Full name; student ID
 *         <<Add additional lead authors here>>
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *         References:
 *         Morelli, R., & Walde, R. (2016).
 *         Java, Java, Java: Object-Oriented Problem Solving
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 *         <<Add more references here>>
 *
 *         Version: 2025-03-29
 */
package mainMenu;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import World.GameLoop;

/**
 * Purpose: The reponsibility of MenuClicker is ...
 *
 * MenuClicker is-a ...
 * MenuClicker is ...
 */
public class MenuClicker implements ActionListener
{

	public MenuClicker()
	{

	}

	public void actionPerformed(ActionEvent e)
	{
		System.out.println("start game");
		new GameLoop();
	}

}
