/**
 * Lead Author(s):
 * 
 * 
 * @author Fern; student ID
 * @author Full name; student ID
 *         <<Add additional lead authors here>>
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *         References:
 *         Morelli, R., & Walde, R. (2016).
 *         Java, Java, Java: Object-Oriented Problem Solving
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 *         <<Add more references here>>
 *
 *         Version: 2025-03-29
 */
package mainMenu;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.*;

/**
 * Purpose: The reponsibility of MainMenu is to let the player start the game
 *
 * MainMenu is-a ...
 * MainMenu is ...
 */
public class MainMenu extends JFrame
{

	public MainMenu()
	{
		// lets the window close upon pressing the X in the corner
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Sets the title of the window to "Gone Fishing"
		this.setTitle("Mountain Game");
		// Sets the window layout to be a BorderLayout
		this.setLayout(new GridLayout(2, 1));
		// Sets the size of the window to be 780p x 380p
		this.setMinimumSize(new Dimension(780, 380));

		JPanel title = new JPanel();
		JButton start = new JButton();
		start.addActionListener(new MenuClicker());
		JButton settings = new JButton();
		settings.addActionListener(new SettingsClicker());
		JLabel highScore = new JLabel();
		JLabel blank = new JLabel();

		JPanel artwork = new JPanel();
		// TODO add artwork
		this.add(artwork);

		title.setLayout(new GridLayout(1, 5));
		title.add(highScore);
		title.add(blank);
		title.add(start);
		title.add(blank);
		title.add(settings);
		this.add(title);

		// packs up the window
		this.pack();
		// sets the window to be visible
		this.setVisible(true);
	}

	public static void main(String[] args)
	{
		new MainMenu();
	}
}
