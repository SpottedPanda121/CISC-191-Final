/**
 * Lead Author(s):
 * 
 * @author Fern; student ID
 * @author Full name; student ID
 *         <<Add additional lead authors here>>
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *         References:
 *         Morelli, R., & Walde, R. (2016).
 *         Java, Java, Java: Object-Oriented Problem Solving
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 *         <<Add more references here>>
 *
 *         Version: 2025-03-29
 */
package project.exam;
import  java.util.EventListener;
import java.util.Scanner;
/**
 * Purpose: The reponsibility of Player is to let the user have input in the
 * game
 *
 * Player is-a ...
 * Player is Movable
 */
public class Player
{
	int x;
	int y;
	
	public Player(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	public void playerUpdate()
	{
		
	}
	
}
